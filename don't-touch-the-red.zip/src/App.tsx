/**
 * @license
 * SPDX-License-Identifier: Apache-2.0
 */

import React, { useEffect, useState, useCallback, useRef } from 'react';
import { GameCanvas } from './components/GameCanvas';
import { HomeScreen } from './components/HomeScreen';
import { PauseModal } from './components/PauseModal';
import { GameOverModal } from './components/GameOverModal';
import { ShopModal } from './components/ShopModal';
import { AchievementsModal } from './components/AchievementsModal';
import { DailyRewardModal } from './components/DailyRewardModal';
import { SettingsModal } from './components/SettingsModal';

import { soundManager } from './audio/soundManager';
import { yandexGames } from './services/yandexSDK';
import { Language } from './utils/i18n';
import {
  Achievement,
  GameSettings,
  GameStats,
  RunSummary,
  SkinId,
} from './types/game';
import {
  addStoredCoins,
  checkDailyRewardClaimed,
  claimDailyReward,
  defaultSettings,
  defaultStats,
  exportLocalStateForCloud,
  getStoredAchievements,
  getStoredCoins,
  getStoredHighScore,
  getStoredLanguage,
  getStoredSelectedSkin,
  getStoredSettings,
  getStoredStats,
  getStoredUnlockedSkins,
  resetAllGameData,
  saveHighScore,
  saveStoredAchievements,
  saveStoredLanguage,
  saveStoredSelectedSkin,
  saveStoredSettings,
  syncCloudDataWithLocal,
  unlockStoredSkin,
  updateLifetimeStats,
} from './utils/storage';

export default function App() {
  const [screen, setScreen] = useState<'HOME' | 'PLAYING'>('HOME');
  const [activeModal, setActiveModal] = useState<
    'PAUSED' | 'GAMEOVER' | 'SHOP' | 'ACHIEVEMENTS' | 'DAILY' | 'SETTINGS' | null
  >(null);

  // Stored state
  const [highScore, setHighScore] = useState(0);
  const [coins, setCoins] = useState(0);
  const [selectedSkinId, setSelectedSkinId] = useState<SkinId>('original_blue');
  const [unlockedSkins, setUnlockedSkins] = useState<SkinId[]>(['original_blue']);
  const [settings, setSettings] = useState<GameSettings>(defaultSettings);
  const [stats, setStats] = useState<GameStats>(defaultStats);
  const [achievements, setAchievements] = useState<Achievement[]>([]);
  const [dailyClaimedToday, setDailyClaimedToday] = useState(false);

  // Language & Fullscreen state
  const [lang, setLang] = useState<Language>('en');
  const [isFullscreen, setIsFullscreen] = useState(false);
  const [isSdkReady, setIsSdkReady] = useState(false);

  // Current run summary for game over screen
  const [lastRunSummary, setLastRunSummary] = useState<RunSummary | null>(null);

  // Game restart key
  const [gameSessionKey, setGameSessionKey] = useState(0);

  // Ref tracking current screen and modal for window listeners
  const screenRef = useRef(screen);
  screenRef.current = screen;
  const activeModalRef = useRef(activeModal);
  activeModalRef.current = activeModal;

  // Initialize SDK, storage, and audio
  useEffect(() => {
    // 1. Initial Local State
    setHighScore(getStoredHighScore());
    setCoins(getStoredCoins());
    setSelectedSkinId(getStoredSelectedSkin());
    setUnlockedSkins(getStoredUnlockedSkins());

    const loadedSettings = getStoredSettings();
    setSettings(loadedSettings);
    soundManager.setConfig(loadedSettings);

    setStats(getStoredStats());
    setAchievements(getStoredAchievements());
    setDailyClaimedToday(checkDailyRewardClaimed());

    // 2. Initialize Yandex SDK asynchronously
    yandexGames
      .init()
      .then(async (res) => {
        // Language detection: user preference takes priority, then SDK environment
        const storedLang = getStoredLanguage();
        const activeLang: Language = storedLang || res.lang || 'en';
        setLang(activeLang);

        // Sync Cloud Saves
        if (res.isAvailable) {
          try {
            const cloudSave = await yandexGames.loadCloudData();
            if (cloudSave) {
              syncCloudDataWithLocal(cloudSave);
              setHighScore(getStoredHighScore());
              setCoins(getStoredCoins());
              setSelectedSkinId(getStoredSelectedSkin());
              setUnlockedSkins(getStoredUnlockedSkins());
              setDailyClaimedToday(checkDailyRewardClaimed());
            }
          } catch (cloudErr) {
            console.warn('[Yandex Cloud] Cloud data sync error:', cloudErr);
          }
        }

        // Notify LoadingAPI.ready() when assets and data are ready
        yandexGames.notifyReady();
        setIsSdkReady(true);
      })
      .catch((err) => {
        console.warn('[YandexSDK] Boot failed, falling back to local play:', err);
        yandexGames.notifyReady();
        setIsSdkReady(true);
      });

    // 3. Audio gesture initialization
    const initAudio = () => {
      soundManager.init();
      window.removeEventListener('pointerdown', initAudio);
      window.removeEventListener('keydown', initAudio);
    };
    window.addEventListener('pointerdown', initAudio, { once: true });
    window.addEventListener('keydown', initAudio, { once: true });

    // 4. Focus, Blur, and Visibility Change Listeners
    const handleVisibilityChange = () => {
      if (document.hidden) {
        soundManager.setPausedOrMuted(true);
        if (screenRef.current === 'PLAYING' && activeModalRef.current !== 'PAUSED') {
          setActiveModal('PAUSED');
          yandexGames.gameplayStop();
        }
      } else {
        soundManager.setPausedOrMuted(false);
      }
    };

    const handleWindowBlur = () => {
      soundManager.setPausedOrMuted(true);
      if (screenRef.current === 'PLAYING' && activeModalRef.current !== 'PAUSED') {
        setActiveModal('PAUSED');
        yandexGames.gameplayStop();
      }
    };

    const handleWindowFocus = () => {
      soundManager.setPausedOrMuted(false);
    };

    const handleFullscreenChange = () => {
      setIsFullscreen(yandexGames.isFullscreen());
    };

    document.addEventListener('visibilitychange', handleVisibilityChange);
    window.addEventListener('blur', handleWindowBlur);
    window.addEventListener('focus', handleWindowFocus);
    document.addEventListener('fullscreenchange', handleFullscreenChange);

    return () => {
      window.removeEventListener('pointerdown', initAudio);
      window.removeEventListener('keydown', initAudio);
      document.removeEventListener('visibilitychange', handleVisibilityChange);
      window.removeEventListener('blur', handleWindowBlur);
      window.removeEventListener('focus', handleWindowFocus);
      document.removeEventListener('fullscreenchange', handleFullscreenChange);
    };
  }, []);

  // Update sound engine whenever settings change
  const handleUpdateSettings = (newSettings: GameSettings) => {
    setSettings(newSettings);
    saveStoredSettings(newSettings);
    soundManager.setConfig(newSettings);
  };

  const handleToggleSound = () => {
    const updated = { ...settings, soundEnabled: !settings.soundEnabled };
    handleUpdateSettings(updated);
  };

  const handleToggleMusic = () => {
    const updated = { ...settings, musicEnabled: !settings.musicEnabled };
    handleUpdateSettings(updated);
  };

  const handleToggleLanguage = (newLang: Language) => {
    setLang(newLang);
    saveStoredLanguage(newLang);
    yandexGames.setLanguage(newLang);
  };

  const handleToggleFullscreen = async () => {
    soundManager.playClick();
    const active = await yandexGames.toggleFullscreen();
    setIsFullscreen(active);
  };

  // Evaluate achievements after run or progress
  const evaluateAchievements = useCallback(
    (currentStats: GameStats, latestScore: number, latestSurvival: number) => {
      const currentList = getStoredAchievements();
      let changed = false;

      const updated = currentList.map((ach) => {
        let currentVal = ach.progress;

        if (ach.id === 'first_run') {
          currentVal = currentStats.totalGames;
        } else if (ach.id === 'score_100') {
          currentVal = Math.max(currentVal, latestScore);
        } else if (ach.id === 'score_250') {
          currentVal = Math.max(currentVal, latestScore);
        } else if (ach.id === 'score_500') {
          currentVal = Math.max(currentVal, latestScore);
        } else if (ach.id === 'score_1000') {
          currentVal = Math.max(currentVal, latestScore);
        } else if (ach.id === 'collect_coins_50') {
          currentVal = currentStats.totalCoins;
        } else if (ach.id === 'collect_stars_25') {
          currentVal = currentStats.totalStars;
        } else if (ach.id === 'dodge_100') {
          currentVal = currentStats.totalObstaclesDodged;
        } else if (ach.id === 'survive_60s') {
          currentVal = Math.max(currentVal, latestSurvival);
        } else if (ach.id === 'fashionista') {
          currentVal = getStoredUnlockedSkins().length;
        }

        const isNowUnlocked = currentVal >= ach.target;
        if (currentVal !== ach.progress || (isNowUnlocked && !ach.unlocked)) {
          changed = true;
          return {
            ...ach,
            progress: currentVal,
            unlocked: ach.unlocked || isNowUnlocked,
          };
        }
        return ach;
      });

      if (changed) {
        setAchievements(updated);
        saveStoredAchievements(updated);
      }
    },
    []
  );

  // Game lifecycle
  const handleStartGame = () => {
    soundManager.init();
    setActiveModal(null);
    setScreen('PLAYING');
    setGameSessionKey((k) => k + 1);
    // Yandex Gameplay API: Start
    yandexGames.gameplayStart();
  };

  const handlePause = () => {
    setActiveModal('PAUSED');
    // Yandex Gameplay API: Stop
    yandexGames.gameplayStop();
  };

  const handleResume = () => {
    setActiveModal(null);
    // Yandex Gameplay API: Resume / Start
    yandexGames.gameplayStart();
  };

  const handleRestart = () => {
    setActiveModal(null);
    setGameSessionKey((k) => k + 1);
    // Yandex Gameplay API: Restart / Start
    yandexGames.gameplayStart();
  };

  const handleHome = () => {
    setActiveModal(null);
    setScreen('HOME');
    // Yandex Gameplay API: Stop
    yandexGames.gameplayStop();
  };

  const handleGameOver = (summary: RunSummary) => {
    // Yandex Gameplay API: Stop
    yandexGames.gameplayStop();

    const isNew = summary.score > highScore;
    if (isNew) {
      saveHighScore(summary.score);
      setHighScore(summary.score);
    }

    if (summary.coinsEarned > 0) {
      const newCoinTotal = addStoredCoins(summary.coinsEarned);
      setCoins(newCoinTotal);
    }

    // Lifetime Stats
    const updatedStats = updateLifetimeStats({
      score: summary.score,
      coins: summary.coinsEarned,
      stars: summary.starsCollected,
      survivalSeconds: summary.survivalTime,
      dodged: summary.score > 0 ? Math.floor(summary.score / 20) : 0,
    });
    setStats(updatedStats);

    // Evaluate Achievements
    evaluateAchievements(updatedStats, summary.score, summary.survivalTime);

    // Sync cloud save
    yandexGames.saveCloudData(exportLocalStateForCloud());

    setLastRunSummary(summary);
    setActiveModal('GAMEOVER');
  };

  // Rewarded Video Ads
  const handleWatchRewardedAd = (onSuccess?: () => void) => {
    soundManager.setPausedOrMuted(true);

    yandexGames.showRewardedVideo({
      onOpen: () => {
        soundManager.setPausedOrMuted(true);
      },
      onRewarded: () => {
        const updated = addStoredCoins(100);
        setCoins(updated);
        soundManager.playCoin();
        onSuccess?.();
        yandexGames.saveCloudData(exportLocalStateForCloud());
      },
      onClose: () => {
        soundManager.setPausedOrMuted(false);
      },
      onError: (err) => {
        console.warn('[Ad Error]:', err);
        soundManager.setPausedOrMuted(false);
      },
    });
  };

  // Shop
  const handleSelectSkin = (skinId: SkinId) => {
    setSelectedSkinId(skinId);
    saveStoredSelectedSkin(skinId);
    yandexGames.saveCloudData(exportLocalStateForCloud());
  };

  const handleBuySkin = (skinId: SkinId, price: number): boolean => {
    if (coins < price) return false;
    const newCoins = addStoredCoins(-price);
    setCoins(newCoins);
    const updatedUnlocked = unlockStoredSkin(skinId);
    setUnlockedSkins(updatedUnlocked);
    setSelectedSkinId(skinId);
    saveStoredSelectedSkin(skinId);

    // Check fashionista achievement
    evaluateAchievements(stats, 0, 0);
    yandexGames.saveCloudData(exportLocalStateForCloud());
    return true;
  };

  // Daily Reward
  const handleClaimDaily = (): boolean => {
    const ok = claimDailyReward();
    if (ok) {
      setDailyClaimedToday(true);
      setCoins(getStoredCoins());
      yandexGames.saveCloudData(exportLocalStateForCloud());
    }
    return ok;
  };

  // Achievement Claiming
  const handleClaimAchievement = (id: string, reward: number) => {
    const updated = achievements.map((a) =>
      a.id === id ? { ...a, claimed: true } : a
    );
    setAchievements(updated);
    saveStoredAchievements(updated);
    const newCoins = addStoredCoins(reward);
    setCoins(newCoins);
    yandexGames.saveCloudData(exportLocalStateForCloud());
  };

  // Reset Progress
  const handleResetProgress = () => {
    resetAllGameData();
    setHighScore(0);
    setCoins(0);
    setSelectedSkinId('original_blue');
    setUnlockedSkins(['original_blue']);
    setStats(defaultStats);
    setAchievements(getStoredAchievements());
    setDailyClaimedToday(false);
    yandexGames.saveCloudData(exportLocalStateForCloud());
  };

  return (
    <div className="w-full h-[100dvh] bg-[#343047] flex items-center justify-center p-0 sm:p-2 md:p-4 overflow-hidden select-none">
      {/* Mobile Shell Frame: adapts dynamically between native full-viewport on mobile/landscape and luxury bezel on desktop */}
      <main className="w-full h-full max-h-[100dvh] sm:h-[96vh] sm:max-h-[890px] sm:max-w-[430px] bg-[#FFF6E9] rounded-none sm:rounded-[36px] sm:shadow-[0_25px_60px_-15px_rgba(0,0,0,0.5)] border-0 sm:border-8 sm:border-[#3E3A52] relative overflow-hidden flex flex-col">
        {/* Top Camera Punch Hole / Speaker Accent for Desktop bezel (hides automatically on short windows) */}
        <div className="hidden min-[640px]:flex max-h-[640px]:hidden justify-center pt-2 pb-1 pointer-events-none z-30">
          <div className="w-16 h-3.5 bg-[#3E3A52] rounded-full flex items-center justify-center">
            <div className="w-2.5 h-2.5 rounded-full bg-[#2B273C] ml-auto mr-1.5" />
          </div>
        </div>

        {/* Dynamic Screen View */}
        <div className="flex-1 relative overflow-hidden flex flex-col">
          {screen === 'HOME' ? (
            <HomeScreen
              highScore={highScore}
              totalCoins={coins}
              selectedSkinId={selectedSkinId}
              dailyRewardAvailable={!dailyClaimedToday}
              soundEnabled={settings.soundEnabled}
              lang={lang}
              isFullscreen={isFullscreen}
              onPlay={handleStartGame}
              onOpenShop={() => setActiveModal('SHOP')}
              onOpenAchievements={() => setActiveModal('ACHIEVEMENTS')}
              onOpenDaily={() => setActiveModal('DAILY')}
              onOpenSettings={() => setActiveModal('SETTINGS')}
              onToggleSound={handleToggleSound}
              onToggleFullscreen={handleToggleFullscreen}
              onWatchRewardedAd={() => handleWatchRewardedAd()}
            />
          ) : (
            <GameCanvas
              key={gameSessionKey}
              selectedSkinId={selectedSkinId}
              reducedMotion={settings.reducedMotion}
              lang={lang}
              onGameOver={handleGameOver}
              onPause={handlePause}
              isPaused={activeModal === 'PAUSED'}
            />
          )}
        </div>

        {/* Modals & Overlays */}
        {activeModal === 'PAUSED' && (
          <PauseModal
            onResume={handleResume}
            onRestart={handleRestart}
            onHome={handleHome}
            soundEnabled={settings.soundEnabled}
            musicEnabled={settings.musicEnabled}
            isFullscreen={isFullscreen}
            lang={lang}
            onToggleSound={handleToggleSound}
            onToggleMusic={handleToggleMusic}
            onToggleFullscreen={handleToggleFullscreen}
          />
        )}

        {activeModal === 'GAMEOVER' && lastRunSummary && (
          <GameOverModal
            summary={lastRunSummary}
            bestScore={highScore}
            selectedSkinId={selectedSkinId}
            lang={lang}
            onPlayAgain={handleRestart}
            onOpenShop={() => setActiveModal('SHOP')}
            onHome={handleHome}
            onWatchRewardedAd={handleWatchRewardedAd}
          />
        )}

        {activeModal === 'SHOP' && (
          <ShopModal
            totalCoins={coins}
            unlockedSkins={unlockedSkins}
            selectedSkinId={selectedSkinId}
            lang={lang}
            onSelectSkin={handleSelectSkin}
            onBuySkin={handleBuySkin}
            onClose={() => setActiveModal(null)}
          />
        )}

        {activeModal === 'ACHIEVEMENTS' && (
          <AchievementsModal
            stats={stats}
            achievements={achievements}
            lang={lang}
            onClaimAchievement={handleClaimAchievement}
            onClose={() => setActiveModal(null)}
          />
        )}

        {activeModal === 'DAILY' && (
          <DailyRewardModal
            isClaimedToday={dailyClaimedToday}
            lang={lang}
            onClaim={handleClaimDaily}
            onClose={() => setActiveModal(null)}
          />
        )}

        {activeModal === 'SETTINGS' && (
          <SettingsModal
            settings={settings}
            lang={lang}
            isFullscreen={isFullscreen}
            onUpdateSettings={handleUpdateSettings}
            onToggleLanguage={handleToggleLanguage}
            onToggleFullscreen={handleToggleFullscreen}
            onResetProgress={handleResetProgress}
            onClose={() => setActiveModal(null)}
          />
        )}
      </main>
    </div>
  );
}
