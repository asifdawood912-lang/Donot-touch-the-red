import React, { useState } from 'react';
import { SKINS } from '../data/skins';
import { SkinId } from '../types/game';
import { soundManager } from '../audio/soundManager';
import { getTranslation, Language } from '../utils/i18n';
import { X, Check, Lock, Sparkles } from 'lucide-react';

interface ShopModalProps {
  totalCoins: number;
  unlockedSkins: SkinId[];
  selectedSkinId: SkinId;
  lang: Language;
  onSelectSkin: (id: SkinId) => void;
  onBuySkin: (id: SkinId, price: number) => boolean;
  onClose: () => void;
}

export const ShopModal: React.FC<ShopModalProps> = ({
  totalCoins,
  unlockedSkins,
  selectedSkinId,
  lang,
  onSelectSkin,
  onBuySkin,
  onClose,
}) => {
  const [unlockedJustNow, setUnlockedJustNow] = useState<SkinId | null>(null);
  const t = getTranslation(lang);

  const handleAction = (skinId: SkinId, price: number, isUnlocked: boolean) => {
    if (isUnlocked) {
      soundManager.playClick();
      onSelectSkin(skinId);
    } else {
      if (totalCoins >= price) {
        const success = onBuySkin(skinId, price);
        if (success) {
          soundManager.playStar();
          setUnlockedJustNow(skinId);
          setTimeout(() => setUnlockedJustNow(null), 1800);
        }
      } else {
        soundManager.playHit();
      }
    }
  };

  return (
    <div className="fixed inset-0 bg-[#343047]/60 backdrop-blur-sm flex items-center justify-center p-4 z-50 overflow-y-auto no-scrollbar">
      <div className="bg-[#FFF6E9] border-2 border-white rounded-3xl w-full max-w-md max-h-[90vh] shadow-2xl flex flex-col overflow-hidden">
        {/* Header */}
        <div className="p-4 sm:p-5 border-b border-slate-200/80 flex items-center justify-between bg-white/60">
          <div>
            <h2 className="font-display font-black text-2xl text-[#343047] flex items-center gap-2">
              <span>{t.shopTitle}</span>
              <Sparkles className="w-5 h-5 text-[#FFD65A]" />
            </h2>
            <p className="text-xs font-semibold text-slate-500">
              {t.shopSubtitle}
            </p>
          </div>

          <div className="flex items-center gap-3">
            {/* Coin balance */}
            <div className="flex items-center gap-1.5 bg-white border border-[#FFD65A] px-3 py-1 rounded-full shadow-xs">
              <span className="text-base">🪙</span>
              <span className="font-display font-bold text-sm text-[#343047] tabular-nums">
                {totalCoins}
              </span>
            </div>

            {/* Close */}
            <button
              onClick={() => {
                soundManager.playClick();
                onClose();
              }}
              className="p-2 rounded-xl bg-white border border-slate-200 text-slate-600 active:scale-90 transition-transform cursor-pointer"
            >
              <X className="w-5 h-5" />
            </button>
          </div>
        </div>

        {/* Skins Grid */}
        <div className="p-4 sm:p-5 overflow-y-auto no-scrollbar grid grid-cols-2 gap-3">
          {Object.values(SKINS).map((skin) => {
            const isUnlocked = unlockedSkins.includes(skin.id);
            const isSelected = selectedSkinId === skin.id;
            const canAfford = totalCoins >= skin.price;
            const justUnlocked = unlockedJustNow === skin.id;

            return (
              <div
                key={skin.id}
                className={`relative bg-white rounded-2xl p-3.5 border-2 flex flex-col items-center text-center transition-all ${
                  isSelected
                    ? 'border-[#72D7FF] shadow-md shadow-[#72D7FF]/20 ring-2 ring-[#72D7FF]/30'
                    : 'border-slate-200/80 hover:border-slate-300'
                } ${justUnlocked ? 'animate-bounce' : ''}`}
              >
                {/* Character Icon Visual */}
                <div
                  className="w-16 h-16 rounded-full flex items-center justify-center my-1 relative shadow-sm"
                  style={{
                    background: skin.isRainbow
                      ? 'linear-gradient(135deg, #FF6B6B, #4ECDC4, #FFE66D)'
                      : skin.isGalaxy
                      ? 'radial-gradient(circle at 35% 35%, #7597DE, #4B1055, #1A0835)'
                      : `radial-gradient(circle at 35% 35%, ${skin.accentColor}, ${skin.primaryColor}, ${skin.secondaryColor})`,
                  }}
                >
                  {/* Accessories */}
                  {skin.hasCrown && (
                    <span className="absolute -top-4 text-base">👑</span>
                  )}
                  {skin.hasLeaves && (
                    <span className="absolute -top-3.5 text-base">🌱</span>
                  )}

                  {/* Face */}
                  <div className="flex flex-col items-center">
                    <div className="flex items-center gap-2 mb-0.5">
                      <div className="w-1.5 h-1.5 rounded-full bg-[#343047]" />
                      <div className="w-1.5 h-1.5 rounded-full bg-[#343047]" />
                    </div>
                    <div className="w-2 h-1 border-b border-[#343047] rounded-b-full" />
                  </div>
                </div>

                {/* Skin Info */}
                <h3 className="font-display font-bold text-sm text-[#343047] mt-1 line-clamp-1">
                  {skin.name}
                </h3>
                <p className="text-[10px] text-slate-400 font-medium line-clamp-1 mb-2">
                  {skin.tagline}
                </p>

                {/* Action button */}
                <div className="w-full mt-auto">
                  {isSelected ? (
                    <div className="w-full py-1.5 px-2 rounded-xl bg-[#72D7FF]/15 text-[#0284c7] font-display font-bold text-xs flex items-center justify-center gap-1">
                      <Check className="w-3.5 h-3.5" />
                      <span>{t.equipped}</span>
                    </div>
                  ) : isUnlocked ? (
                    <button
                      onClick={() => handleAction(skin.id, skin.price, true)}
                      className="w-full py-1.5 px-2 rounded-xl bg-slate-100 hover:bg-slate-200 text-[#343047] font-display font-bold text-xs active:scale-95 transition-transform cursor-pointer"
                    >
                      {t.equip}
                    </button>
                  ) : (
                    <button
                      onClick={() => handleAction(skin.id, skin.price, false)}
                      disabled={!canAfford}
                      className={`w-full py-1.5 px-2 rounded-xl font-display font-bold text-xs flex items-center justify-center gap-1.5 transition-transform active:scale-95 cursor-pointer ${
                        canAfford
                          ? 'bg-[#FFD65A] text-[#343047] shadow-sm hover:brightness-105'
                          : 'bg-slate-100 text-slate-400 cursor-not-allowed opacity-80'
                      }`}
                    >
                      <Lock className="w-3 h-3" />
                      <span>{skin.price} {t.coins}</span>
                    </button>
                  )}
                </div>
              </div>
            );
          })}
        </div>

        {/* Footer info */}
        <div className="p-3 bg-white/70 border-t border-slate-200/80 text-center">
          <p className="text-[11px] font-medium text-slate-500">
            {t.shopHint}
          </p>
        </div>
      </div>
    </div>
  );
};
