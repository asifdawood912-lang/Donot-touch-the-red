import React, { useState } from 'react';
import { Check, Sparkles, X } from 'lucide-react';
import { soundManager } from '../audio/soundManager';
import { getTranslation, Language } from '../utils/i18n';

interface DailyRewardModalProps {
  isClaimedToday: boolean;
  lang: Language;
  onClaim: () => boolean;
  onClose: () => void;
}

export const DailyRewardModal: React.FC<DailyRewardModalProps> = ({
  isClaimedToday,
  lang,
  onClaim,
  onClose,
}) => {
  const [opening, setOpening] = useState(false);
  const [claimedJustNow, setClaimedJustNow] = useState(false);
  const t = getTranslation(lang);

  const handleClaim = () => {
    if (isClaimedToday || opening || claimedJustNow) return;

    setOpening(true);
    soundManager.playStar();

    setTimeout(() => {
      onClaim();
      setOpening(false);
      setClaimedJustNow(true);
    }, 600);
  };

  return (
    <div className="fixed inset-0 bg-[#343047]/60 backdrop-blur-sm flex items-center justify-center p-4 z-50">
      <div className="bg-[#FFF6E9] border-2 border-white rounded-3xl p-6 w-full max-w-xs shadow-2xl text-center flex flex-col items-center">
        {/* Close Button */}
        <div className="w-full flex justify-end">
          <button
            onClick={() => {
              soundManager.playClick();
              onClose();
            }}
            className="p-1.5 rounded-xl bg-white border border-slate-200 text-slate-500 active:scale-90"
          >
            <X className="w-4 h-4" />
          </button>
        </div>

        {/* Gift Box Icon with opening animation */}
        <div 
          onClick={handleClaim}
          className={`relative my-3 cursor-pointer ${
            !isClaimedToday && !claimedJustNow ? 'animate-cute-bounce' : ''
          }`}
        >
          <div
            className={`w-24 h-24 rounded-3xl flex items-center justify-center text-5xl shadow-lg border-2 border-white transition-all ${
              isClaimedToday || claimedJustNow
                ? 'bg-emerald-100 text-emerald-600'
                : 'bg-gradient-to-tr from-[#FF4D65] to-[#FF88AA] text-white shadow-[#FF4D65]/25'
            } ${opening ? 'scale-110 rotate-6' : ''}`}
          >
            {claimedJustNow || isClaimedToday ? '🎉' : '🎁'}
          </div>

          {!isClaimedToday && !claimedJustNow && (
            <div className="absolute -top-2 -right-2 bg-[#FFD65A] text-[#343047] font-display font-extrabold text-[10px] px-2 py-0.5 rounded-full shadow-sm animate-pulse">
              +50 🪙
            </div>
          )}
        </div>

        <h3 className="font-display font-black text-2xl text-[#343047]">
          {t.dailyTitle}
        </h3>
        <p className="text-xs font-semibold text-slate-500 mt-1 mb-5">
          {isClaimedToday || claimedJustNow
            ? t.dailySubtitleClaimed
            : t.dailySubtitleAvailable}
        </p>

        {/* Claim Action */}
        <div className="w-full">
          {isClaimedToday || claimedJustNow ? (
            <div className="w-full py-3 px-4 rounded-2xl bg-emerald-50 border border-emerald-200 text-emerald-700 font-display font-bold text-sm flex items-center justify-center gap-2">
              <Check className="w-4 h-4 stroke-[3]" />
              <span>{t.claimedToday}</span>
            </div>
          ) : (
            <button
              onClick={handleClaim}
              disabled={opening}
              className="w-full py-3.5 px-4 rounded-2xl font-display font-bold text-base text-[#343047] bg-[#FFD65A] hover:bg-[#ffcf3e] shadow-md shadow-[#FFD65A]/30 active:scale-95 transition-transform flex items-center justify-center gap-2 cursor-pointer"
            >
              <Sparkles className="w-4 h-4" />
              <span>{t.claimReward}</span>
            </button>
          )}
        </div>
      </div>
    </div>
  );
};
