import React from 'react';
import { Achievement, GameStats } from '../types/game';
import { soundManager } from '../audio/soundManager';
import { getTranslation, Language } from '../utils/i18n';
import { X, Trophy, Award, Flame, Check, Sparkles } from 'lucide-react';

interface AchievementsModalProps {
  stats: GameStats;
  achievements: Achievement[];
  lang: Language;
  onClaimAchievement: (id: string, reward: number) => void;
  onClose: () => void;
}

export const AchievementsModal: React.FC<AchievementsModalProps> = ({
  stats,
  achievements,
  lang,
  onClaimAchievement,
  onClose,
}) => {
  const t = getTranslation(lang);

  return (
    <div className="fixed inset-0 bg-[#343047]/60 backdrop-blur-sm flex items-center justify-center p-4 z-50 overflow-y-auto no-scrollbar">
      <div className="bg-[#FFF6E9] border-2 border-white rounded-3xl w-full max-w-md max-h-[90vh] shadow-2xl flex flex-col overflow-hidden">
        {/* Header */}
        <div className="p-4 sm:p-5 border-b border-slate-200/80 flex items-center justify-between bg-white/60">
          <div>
            <h2 className="font-display font-black text-2xl text-[#343047] flex items-center gap-2">
              <span>{t.statsTitle}</span>
              <Trophy className="w-5 h-5 text-[#FFD65A]" />
            </h2>
            <p className="text-xs font-semibold text-slate-500">
              {t.statsSubtitle}
            </p>
          </div>

          <button
            onClick={() => {
              soundManager.playClick();
              onClose();
            }}
            className="p-2 rounded-xl bg-white border border-slate-200 text-slate-600 active:scale-90 transition-transform cursor-pointer"
          >
            <X className="w-5 h-5" />
          </button>
        </div>

        {/* Content Container */}
        <div className="p-4 sm:p-5 overflow-y-auto no-scrollbar flex flex-col gap-5">
          {/* Lifetime Stats Overview Grid */}
          <div>
            <h3 className="font-display font-bold text-xs uppercase tracking-wider text-slate-400 mb-2.5 flex items-center gap-1.5">
              <Flame className="w-4 h-4 text-[#FF4D65]" />
              <span>{t.careerRecords}</span>
            </h3>

            <div className="grid grid-cols-3 gap-2">
              <div className="bg-white p-3 rounded-2xl border border-slate-200/80 flex flex-col items-center text-center">
                <span className="text-[10px] font-semibold text-slate-400 uppercase">{t.personalBest}</span>
                <span className="font-display font-black text-lg text-[#343047] tabular-nums mt-0.5">
                  {stats.highScore}
                </span>
              </div>

              <div className="bg-white p-3 rounded-2xl border border-slate-200/80 flex flex-col items-center text-center">
                <span className="text-[10px] font-semibold text-slate-400 uppercase">{t.runsPlayed}</span>
                <span className="font-display font-black text-lg text-[#343047] tabular-nums mt-0.5">
                  {stats.totalGames}
                </span>
              </div>

              <div className="bg-white p-3 rounded-2xl border border-slate-200/80 flex flex-col items-center text-center">
                <span className="text-[10px] font-semibold text-slate-400 uppercase">{t.bestTime}</span>
                <span className="font-display font-black text-lg text-[#343047] tabular-nums mt-0.5">
                  {stats.longestSurvivalTime}s
                </span>
              </div>

              <div className="bg-white p-3 rounded-2xl border border-slate-200/80 flex flex-col items-center text-center">
                <span className="text-[10px] font-semibold text-slate-400 uppercase">{t.starsGot}</span>
                <span className="font-display font-black text-lg text-[#343047] tabular-nums mt-0.5">
                  {stats.totalStars}
                </span>
              </div>

              <div className="bg-white p-3 rounded-2xl border border-slate-200/80 flex flex-col items-center text-center">
                <span className="text-[10px] font-semibold text-slate-400 uppercase">{t.coinsEarned}</span>
                <span className="font-display font-black text-lg text-[#343047] tabular-nums mt-0.5">
                  {stats.totalCoins}
                </span>
              </div>

              <div className="bg-white p-3 rounded-2xl border border-slate-200/80 flex flex-col items-center text-center">
                <span className="text-[10px] font-semibold text-slate-400 uppercase">{t.hazardsDodged}</span>
                <span className="font-display font-black text-lg text-[#343047] tabular-nums mt-0.5">
                  {stats.totalObstaclesDodged}
                </span>
              </div>
            </div>
          </div>

          {/* Achievements List */}
          <div>
            <h3 className="font-display font-bold text-xs uppercase tracking-wider text-slate-400 mb-2.5 flex items-center gap-1.5">
              <Award className="w-4 h-4 text-[#72D7FF]" />
              <span>{t.milestonesRewards}</span>
            </h3>

            <div className="flex flex-col gap-2">
              {achievements.map((item) => {
                const currentProgress = Math.min(item.progress, item.target);
                const pct = Math.floor((currentProgress / item.target) * 100);
                const isReadyToClaim = item.unlocked && !item.claimed;

                return (
                  <div
                    key={item.id}
                    className={`bg-white rounded-2xl p-3 border-2 flex items-center justify-between gap-3 ${
                      isReadyToClaim
                        ? 'border-[#FFD65A] bg-[#FFFBEB]'
                        : item.claimed
                        ? 'border-slate-200/60 opacity-75'
                        : 'border-slate-200/80'
                    }`}
                  >
                    {/* Icon */}
                    <div className="w-11 h-11 rounded-xl bg-slate-100 flex items-center justify-center text-xl shrink-0">
                      {item.icon}
                    </div>

                    {/* Text & Progress */}
                    <div className="flex-1 min-w-0">
                      <div className="flex items-center justify-between">
                        <h4 className="font-display font-bold text-sm text-[#343047] truncate">
                          {item.title}
                        </h4>
                        <span className="text-[11px] font-bold text-slate-500 tabular-nums">
                          {currentProgress} / {item.target}
                        </span>
                      </div>
                      <p className="text-[11px] text-slate-500 line-clamp-1 mt-0.5">
                        {item.description}
                      </p>

                      {/* Progress bar */}
                      <div className="w-full h-1.5 bg-slate-100 rounded-full overflow-hidden mt-1.5">
                        <div
                          className="h-full bg-gradient-to-r from-[#72D7FF] to-[#B8A7FF] rounded-full transition-all duration-300"
                          style={{ width: `${pct}%` }}
                        />
                      </div>
                    </div>

                    {/* Claim / Reward Status */}
                    <div className="shrink-0 pl-1">
                      {item.claimed ? (
                        <div className="p-1.5 rounded-full bg-emerald-50 text-emerald-600" title="Claimed">
                          <Check className="w-4 h-4 stroke-[3]" />
                        </div>
                      ) : isReadyToClaim ? (
                        <button
                          onClick={() => {
                            soundManager.playStar();
                            onClaimAchievement(item.id, item.rewardCoins);
                          }}
                          className="py-1 px-3 rounded-xl bg-[#FFD65A] hover:bg-[#ffcf3e] text-[#343047] font-display font-bold text-xs flex items-center gap-1 shadow-sm animate-pulse active:scale-95 transition-transform cursor-pointer"
                        >
                          <Sparkles className="w-3.5 h-3.5" />
                          <span>+{item.rewardCoins}</span>
                        </button>
                      ) : (
                        <div className="text-right">
                          <span className="text-[11px] font-bold text-slate-400">
                            +{item.rewardCoins} 🪙
                          </span>
                        </div>
                      )}
                    </div>
                  </div>
                );
              })}
            </div>
          </div>
        </div>
      </div>
    </div>
  );
};
