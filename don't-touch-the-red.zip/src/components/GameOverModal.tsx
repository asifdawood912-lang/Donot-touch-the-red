import React, { useState } from 'react';
import { RotateCcw, Home, ShoppingBag, Trophy, Tv, Check } from 'lucide-react';
import { RunSummary, SkinId } from '../types/game';
import { SKINS } from '../data/skins';
import { soundManager } from '../audio/soundManager';
import { getTranslation, Language } from '../utils/i18n';

interface GameOverModalProps {
  summary: RunSummary;
  bestScore: number;
  selectedSkinId: SkinId;
  lang: Language;
  onPlayAgain: () => void;
  onOpenShop: () => void;
  onHome: () => void;
  onWatchRewardedAd: (onSuccess: () => void) => void;
}

export const GameOverModal: React.FC<GameOverModalProps> = ({
  summary,
  bestScore,
  selectedSkinId,
  lang,
  onPlayAgain,
  onOpenShop,
  onHome,
  onWatchRewardedAd,
}) => {
  const [adRewardClaimed, setAdRewardClaimed] = useState(false);
  const isNewRecord = summary.score > bestScore;
  const skin = SKINS[selectedSkinId] || SKINS.original_blue;
  const t = getTranslation(lang);

  const handleWatchAd = () => {
    if (adRewardClaimed) return;
    onWatchRewardedAd(() => {
      setAdRewardClaimed(true);
      soundManager.playStar();
    });
  };

  return (
    <div className="fixed inset-0 bg-[#343047]/65 backdrop-blur-md flex items-center justify-center p-4 z-50 overflow-y-auto no-scrollbar">
      <div className="bg-[#FFF6E9] border-2 border-white rounded-3xl p-5 sm:p-6 w-full max-w-sm shadow-2xl text-center flex flex-col items-center">
        {/* New Record Banner if high score broken */}
        {isNewRecord && (
          <div className="bg-gradient-to-r from-[#FFD65A] to-[#FFAE33] text-[#343047] px-4 py-1.5 rounded-full font-display font-extrabold text-xs uppercase tracking-wider shadow-md mb-3 animate-bounce">
            {t.newRecord}
          </div>
        )}

        {/* Shocked Mascot Expression */}
        <div className="relative my-2">
          {/* Dizzy Stars orbiting */}
          <div className="absolute -top-3 left-0 text-lg animate-spin">💫</div>
          <div className="absolute -top-3 right-0 text-lg animate-spin">⭐</div>

          <div
            className="w-20 h-20 rounded-full flex items-center justify-center shadow-lg mx-auto"
            style={{
              background: skin.isRainbow
                ? 'linear-gradient(135deg, #FF6B6B, #4ECDC4, #FFE66D)'
                : skin.isGalaxy
                ? 'radial-gradient(circle at 35% 35%, #7597DE, #4B1055, #1A0835)'
                : `radial-gradient(circle at 35% 35%, ${skin.accentColor}, ${skin.primaryColor}, ${skin.secondaryColor})`,
            }}
          >
            {/* Surprised Shocked Face */}
            <div className="flex flex-col items-center">
              {/* X eyes */}
              <div className="flex items-center gap-3 font-display font-black text-base text-[#343047]">
                <span>✕</span>
                <span>✕</span>
              </div>
              {/* Big shocked open O mouth */}
              <div className="w-3.5 h-4.5 rounded-full bg-[#343047] mt-1" />
            </div>
          </div>
        </div>

        {/* Heading */}
        <h2 className="font-display font-black text-3xl text-[#FF4D65] tracking-tight mt-1">
          {t.gameOverTitle}
        </h2>
        <p className="text-xs font-semibold text-slate-500 mt-0.5 mb-3">
          {summary.cause || t.touchedRed}
        </p>

        {/* Score Summary Card */}
        <div className="w-full bg-white/90 border border-slate-200/90 rounded-2xl p-3.5 shadow-sm mb-4 flex flex-col gap-2.5">
          {/* Big Final Score */}
          <div className="flex flex-col items-center pb-2 border-b border-slate-100">
            <span className="text-[11px] font-semibold text-slate-400 uppercase tracking-wider">{t.finalScore}</span>
            <span className="font-display font-black text-4xl text-[#343047] tabular-nums">
              {summary.score}
            </span>
          </div>

          {/* Detailed stats */}
          <div className="grid grid-cols-3 gap-2 text-center pt-0.5">
            <div className="flex flex-col items-center">
              <span className="text-[10px] font-semibold text-slate-400 uppercase">{t.personalBest}</span>
              <div className="flex items-center gap-1 font-display font-bold text-sm text-[#343047] tabular-nums mt-0.5">
                <Trophy className="w-3.5 h-3.5 text-[#FFD65A]" />
                <span>{Math.max(summary.score, bestScore)}</span>
              </div>
            </div>

            <div className="flex flex-col items-center">
              <span className="text-[10px] font-semibold text-slate-400 uppercase">{t.coins}</span>
              <div className="flex items-center gap-1 font-display font-bold text-sm text-[#343047] tabular-nums mt-0.5">
                <span>🪙</span>
                <span>+{summary.coinsEarned}</span>
              </div>
            </div>

            <div className="flex flex-col items-center">
              <span className="text-[10px] font-semibold text-slate-400 uppercase">{t.survived}</span>
              <div className="flex items-center gap-1 font-display font-bold text-sm text-[#343047] tabular-nums mt-0.5">
                <span>⏱️</span>
                <span>{summary.survivalTime}s</span>
              </div>
            </div>
          </div>
        </div>

        {/* Optional Rewarded Ad Bonus */}
        <div className="w-full mb-3">
          {adRewardClaimed ? (
            <div className="w-full py-2 px-3 rounded-xl bg-emerald-50 border border-emerald-200 text-emerald-700 font-display font-bold text-xs flex items-center justify-center gap-1.5">
              <Check className="w-4 h-4 stroke-[3]" />
              <span>{t.adWatchedSuccess}</span>
            </div>
          ) : (
            <button
              onClick={handleWatchAd}
              className="w-full py-2 px-3 rounded-xl bg-amber-50 hover:bg-amber-100 border border-amber-200/90 text-amber-800 font-display font-bold text-xs flex items-center justify-center gap-1.5 active:scale-95 transition-all cursor-pointer"
            >
              <Tv className="w-3.5 h-3.5 text-amber-600" />
              <span>{t.watchAdCoins}</span>
            </button>
          )}
        </div>

        {/* Actions */}
        <div className="w-full flex flex-col gap-2">
          {/* Play Again (Primary CTA) */}
          <button
            onClick={() => {
              soundManager.playClick();
              onPlayAgain();
            }}
            className="w-full py-3.5 px-4 rounded-2xl font-display font-bold text-lg text-white bg-gradient-to-r from-[#FF4D65] to-[#FF6B81] shadow-lg shadow-[#FF4D65]/30 active:scale-95 transition-transform flex items-center justify-center gap-2 cursor-pointer"
          >
            <RotateCcw className="w-5 h-5" />
            <span>{t.playAgain}</span>
          </button>

          {/* Secondary Shop & Home */}
          <div className="grid grid-cols-2 gap-2">
            <button
              onClick={() => {
                soundManager.playClick();
                onOpenShop();
              }}
              className="py-2.5 px-3 rounded-2xl bg-white border border-slate-200 font-display font-bold text-xs text-[#343047] shadow-sm active:scale-95 transition-transform flex items-center justify-center gap-1.5"
            >
              <ShoppingBag className="w-4 h-4 text-[#72D7FF]" />
              <span>{t.shopSkins}</span>
            </button>

            <button
              onClick={() => {
                soundManager.playClick();
                onHome();
              }}
              className="py-2.5 px-3 rounded-2xl bg-white border border-slate-200 font-display font-bold text-xs text-[#343047] shadow-sm active:scale-95 transition-transform flex items-center justify-center gap-1.5"
            >
              <Home className="w-4 h-4 text-slate-600" />
              <span>{t.home}</span>
            </button>
          </div>
        </div>
      </div>
    </div>
  );
};
