import React from 'react';
import { Play, RotateCcw, Home, Volume2, VolumeX, Music, Maximize2, Minimize2 } from 'lucide-react';
import { soundManager } from '../audio/soundManager';
import { getTranslation, Language } from '../utils/i18n';

interface PauseModalProps {
  onResume: () => void;
  onRestart: () => void;
  onHome: () => void;
  soundEnabled: boolean;
  musicEnabled: boolean;
  isFullscreen: boolean;
  lang: Language;
  onToggleSound: () => void;
  onToggleMusic: () => void;
  onToggleFullscreen: () => void;
}

export const PauseModal: React.FC<PauseModalProps> = ({
  onResume,
  onRestart,
  onHome,
  soundEnabled,
  musicEnabled,
  isFullscreen,
  lang,
  onToggleSound,
  onToggleMusic,
  onToggleFullscreen,
}) => {
  const t = getTranslation(lang);

  return (
    <div className="fixed inset-0 bg-[#343047]/60 backdrop-blur-sm flex items-center justify-center p-4 z-50">
      <div className="bg-[#FFF6E9] border-2 border-white rounded-3xl p-6 w-full max-w-xs shadow-2xl text-center flex flex-col items-center animate-cute-bounce">
        {/* Header */}
        <div className="w-12 h-12 rounded-2xl bg-white border border-slate-200 flex items-center justify-center shadow-sm mb-3 text-2xl">
          ⏸️
        </div>

        <h2 className="font-display font-black text-2xl text-[#343047] tracking-tight">
          {t.pausedTitle}
        </h2>
        <p className="text-xs font-medium text-slate-500 mt-1 mb-5">
          {t.pausedSubtitle}
        </p>

        {/* Action Buttons */}
        <div className="w-full flex flex-col gap-2.5">
          {/* Resume */}
          <button
            onClick={() => {
              soundManager.playClick();
              onResume();
            }}
            className="w-full py-3.5 px-4 rounded-2xl font-display font-bold text-base text-white bg-[#72D7FF] shadow-md shadow-[#72D7FF]/30 active:scale-95 transition-transform flex items-center justify-center gap-2 cursor-pointer"
          >
            <Play className="w-5 h-5 fill-current" />
            <span>{t.resumeGame}</span>
          </button>

          {/* Restart */}
          <button
            onClick={() => {
              soundManager.playClick();
              onRestart();
            }}
            className="w-full py-3 px-4 rounded-2xl font-display font-bold text-sm text-[#343047] bg-white border border-slate-200 shadow-sm active:scale-95 transition-transform flex items-center justify-center gap-2 cursor-pointer"
          >
            <RotateCcw className="w-4 h-4 text-[#FF4D65]" />
            <span>{t.restartRun}</span>
          </button>

          {/* Home */}
          <button
            onClick={() => {
              soundManager.playClick();
              onHome();
            }}
            className="w-full py-3 px-4 rounded-2xl font-display font-semibold text-sm text-slate-600 bg-transparent hover:bg-black/5 active:scale-95 transition-transform flex items-center justify-center gap-2 cursor-pointer"
          >
            <Home className="w-4 h-4" />
            <span>{t.mainMenu}</span>
          </button>
        </div>

        {/* Audio & Fullscreen Quick Toggles */}
        <div className="w-full pt-4 mt-4 border-t border-slate-200/80 flex items-center justify-center gap-2.5">
          <button
            onClick={onToggleSound}
            className={`p-2 rounded-xl border flex items-center gap-1.5 text-xs font-semibold ${
              soundEnabled ? 'bg-white border-slate-200 text-slate-700' : 'bg-slate-100 border-slate-300 text-slate-400'
            }`}
          >
            {soundEnabled ? <Volume2 className="w-4 h-4 text-[#72D7FF]" /> : <VolumeX className="w-4 h-4" />}
            <span>SFX</span>
          </button>

          <button
            onClick={onToggleMusic}
            className={`p-2 rounded-xl border flex items-center gap-1.5 text-xs font-semibold ${
              musicEnabled ? 'bg-white border-slate-200 text-slate-700' : 'bg-slate-100 border-slate-300 text-slate-400'
            }`}
          >
            <Music className={`w-4 h-4 ${musicEnabled ? 'text-[#B8A7FF]' : 'text-slate-400'}`} />
            <span>BGM</span>
          </button>

          <button
            onClick={onToggleFullscreen}
            className="p-2 rounded-xl border bg-white border-slate-200 text-slate-700 flex items-center gap-1.5 text-xs font-semibold"
            title={t.fullscreenToggle}
          >
            {isFullscreen ? <Minimize2 className="w-4 h-4 text-[#72D7FF]" /> : <Maximize2 className="w-4 h-4" />}
          </button>
        </div>
      </div>
    </div>
  );
};
