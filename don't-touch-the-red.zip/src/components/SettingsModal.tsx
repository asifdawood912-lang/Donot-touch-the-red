import React, { useState } from 'react';
import { GameSettings } from '../types/game';
import { soundManager } from '../audio/soundManager';
import { getTranslation, Language } from '../utils/i18n';
import { X, Volume2, Music, Smartphone, Eye, Trash2, AlertTriangle, Maximize2, Minimize2, Globe } from 'lucide-react';

interface SettingsModalProps {
  settings: GameSettings;
  lang: Language;
  isFullscreen: boolean;
  onUpdateSettings: (newSettings: GameSettings) => void;
  onToggleLanguage: (newLang: Language) => void;
  onToggleFullscreen: () => void;
  onResetProgress: () => void;
  onClose: () => void;
}

export const SettingsModal: React.FC<SettingsModalProps> = ({
  settings,
  lang,
  isFullscreen,
  onUpdateSettings,
  onToggleLanguage,
  onToggleFullscreen,
  onResetProgress,
  onClose,
}) => {
  const [showConfirmReset, setShowConfirmReset] = useState(false);
  const t = getTranslation(lang);

  const toggle = (key: keyof GameSettings) => {
    soundManager.playClick();
    const updated = {
      ...settings,
      [key]: !settings[key],
    };
    onUpdateSettings(updated);
  };

  const handleVolume = (vol: number) => {
    const updated = {
      ...settings,
      masterVolume: vol,
    };
    onUpdateSettings(updated);
  };

  return (
    <div className="fixed inset-0 bg-[#343047]/60 backdrop-blur-sm flex items-center justify-center p-4 z-50 overflow-y-auto no-scrollbar">
      <div className="bg-[#FFF6E9] border-2 border-white rounded-3xl w-full max-w-sm shadow-2xl p-5 flex flex-col">
        {/* Header */}
        <div className="flex items-center justify-between pb-3 border-b border-slate-200/80 mb-3.5">
          <h2 className="font-display font-black text-2xl text-[#343047]">
            {t.settings}
          </h2>

          <button
            onClick={() => {
              soundManager.playClick();
              onClose();
            }}
            className="p-1.5 rounded-xl bg-white border border-slate-200 text-slate-600 active:scale-90 transition-transform"
          >
            <X className="w-5 h-5" />
          </button>
        </div>

        {/* Toggles */}
        <div className="flex flex-col gap-2.5 max-h-[62vh] overflow-y-auto no-scrollbar pr-0.5">
          {/* Language Switcher */}
          <div className="bg-white p-3 rounded-2xl border border-slate-200/80 flex items-center justify-between">
            <div className="flex items-center gap-2.5">
              <div className="p-2 rounded-xl bg-indigo-50 text-indigo-600">
                <Globe className="w-4 h-4" />
              </div>
              <div className="flex flex-col">
                <span className="font-display font-bold text-sm text-[#343047]">{t.languageSetting}</span>
                <span className="text-[10px] text-slate-400">{t.languageSubtitle}</span>
              </div>
            </div>

            <div className="flex items-center gap-1 bg-slate-100 p-1 rounded-xl">
              <button
                onClick={() => {
                  soundManager.playClick();
                  onToggleLanguage('en');
                }}
                className={`px-2.5 py-1 rounded-lg text-xs font-bold transition-all ${
                  lang === 'en' ? 'bg-white text-[#343047] shadow-xs' : 'text-slate-500'
                }`}
              >
                EN
              </button>
              <button
                onClick={() => {
                  soundManager.playClick();
                  onToggleLanguage('ru');
                }}
                className={`px-2.5 py-1 rounded-lg text-xs font-bold transition-all ${
                  lang === 'ru' ? 'bg-white text-[#343047] shadow-xs' : 'text-slate-500'
                }`}
              >
                RU
              </button>
            </div>
          </div>

          {/* Fullscreen Toggle */}
          <div className="bg-white p-3 rounded-2xl border border-slate-200/80 flex items-center justify-between">
            <div className="flex items-center gap-2.5">
              <div className="p-2 rounded-xl bg-teal-50 text-teal-600">
                <Maximize2 className="w-4 h-4" />
              </div>
              <div className="flex flex-col">
                <span className="font-display font-bold text-sm text-[#343047]">{t.fullscreenToggle}</span>
                <span className="text-[10px] text-slate-400">{t.fullscreenSubtitle}</span>
              </div>
            </div>

            <button
              onClick={onToggleFullscreen}
              className={`px-3 py-1.5 rounded-xl border text-xs font-bold transition-all flex items-center gap-1.5 ${
                isFullscreen
                  ? 'bg-teal-50 border-teal-200 text-teal-700'
                  : 'bg-slate-100 border-slate-200 text-slate-600'
              }`}
            >
              {isFullscreen ? <Minimize2 className="w-3.5 h-3.5" /> : <Maximize2 className="w-3.5 h-3.5" />}
              <span>{isFullscreen ? 'ON' : 'OFF'}</span>
            </button>
          </div>

          {/* Sound FX */}
          <div className="bg-white p-3 rounded-2xl border border-slate-200/80 flex items-center justify-between">
            <div className="flex items-center gap-2.5">
              <div className="p-2 rounded-xl bg-sky-50 text-[#72D7FF]">
                <Volume2 className="w-4 h-4" />
              </div>
              <div className="flex flex-col">
                <span className="font-display font-bold text-sm text-[#343047]">{t.soundEffects}</span>
                <span className="text-[10px] text-slate-400">{t.soundSubtitle}</span>
              </div>
            </div>

            <button
              onClick={() => toggle('soundEnabled')}
              className={`w-11 h-6 rounded-full p-0.5 transition-colors ${
                settings.soundEnabled ? 'bg-[#72D7FF]' : 'bg-slate-300'
              }`}
            >
              <div
                className={`w-5 h-5 rounded-full bg-white shadow-sm transition-transform ${
                  settings.soundEnabled ? 'translate-x-5' : 'translate-x-0'
                }`}
              />
            </button>
          </div>

          {/* Music */}
          <div className="bg-white p-3 rounded-2xl border border-slate-200/80 flex items-center justify-between">
            <div className="flex items-center gap-2.5">
              <div className="p-2 rounded-xl bg-purple-50 text-[#B8A7FF]">
                <Music className="w-4 h-4" />
              </div>
              <div className="flex flex-col">
                <span className="font-display font-bold text-sm text-[#343047]">{t.bgmMelody}</span>
                <span className="text-[10px] text-slate-400">{t.bgmSubtitle}</span>
              </div>
            </div>

            <button
              onClick={() => toggle('musicEnabled')}
              className={`w-11 h-6 rounded-full p-0.5 transition-colors ${
                settings.musicEnabled ? 'bg-[#B8A7FF]' : 'bg-slate-300'
              }`}
            >
              <div
                className={`w-5 h-5 rounded-full bg-white shadow-sm transition-transform ${
                  settings.musicEnabled ? 'translate-x-5' : 'translate-x-0'
                }`}
              />
            </button>
          </div>

          {/* Vibration */}
          <div className="bg-white p-3 rounded-2xl border border-slate-200/80 flex items-center justify-between">
            <div className="flex items-center gap-2.5">
              <div className="p-2 rounded-xl bg-amber-50 text-[#FFD65A]">
                <Smartphone className="w-4 h-4" />
              </div>
              <div className="flex flex-col">
                <span className="font-display font-bold text-sm text-[#343047]">{t.vibrationHaptics}</span>
                <span className="text-[10px] text-slate-400">{t.vibrationSubtitle}</span>
              </div>
            </div>

            <button
              onClick={() => toggle('vibrationEnabled')}
              className={`w-11 h-6 rounded-full p-0.5 transition-colors ${
                settings.vibrationEnabled ? 'bg-[#FFD65A]' : 'bg-slate-300'
              }`}
            >
              <div
                className={`w-5 h-5 rounded-full bg-white shadow-sm transition-transform ${
                  settings.vibrationEnabled ? 'translate-x-5' : 'translate-x-0'
                }`}
              />
            </button>
          </div>

          {/* Reduced Motion */}
          <div className="bg-white p-3 rounded-2xl border border-slate-200/80 flex items-center justify-between">
            <div className="flex items-center gap-2.5">
              <div className="p-2 rounded-xl bg-emerald-50 text-[#8DE5B5]">
                <Eye className="w-4 h-4" />
              </div>
              <div className="flex flex-col">
                <span className="font-display font-bold text-sm text-[#343047]">{t.reducedMotion}</span>
                <span className="text-[10px] text-slate-400">{t.motionSubtitle}</span>
              </div>
            </div>

            <button
              onClick={() => toggle('reducedMotion')}
              className={`w-11 h-6 rounded-full p-0.5 transition-colors ${
                settings.reducedMotion ? 'bg-[#8DE5B5]' : 'bg-slate-300'
              }`}
            >
              <div
                className={`w-5 h-5 rounded-full bg-white shadow-sm transition-transform ${
                  settings.reducedMotion ? 'translate-x-5' : 'translate-x-0'
                }`}
              />
            </button>
          </div>

          {/* Master Volume Slider */}
          <div className="bg-white p-3 rounded-2xl border border-slate-200/80 flex flex-col gap-1.5">
            <div className="flex items-center justify-between">
              <span className="font-display font-bold text-xs text-[#343047]">{t.masterVolume}</span>
              <span className="text-[11px] font-bold text-slate-400 tabular-nums">
                {Math.round(settings.masterVolume * 100)}%
              </span>
            </div>
            <input
              type="range"
              min="0"
              max="1"
              step="0.05"
              value={settings.masterVolume}
              onChange={(e) => handleVolume(parseFloat(e.target.value))}
              className="w-full accent-[#72D7FF] h-2 bg-slate-200 rounded-lg cursor-pointer"
            />
          </div>
        </div>

        {/* Reset Data Section */}
        <div className="mt-3 pt-3 border-t border-slate-200/80">
          {showConfirmReset ? (
            <div className="bg-rose-50 border border-rose-200 rounded-2xl p-3 flex flex-col items-center text-center">
              <div className="flex items-center gap-1.5 text-xs font-bold text-[#FF4D65] mb-1">
                <AlertTriangle className="w-4 h-4" />
                <span>{t.resetConfirmTitle}</span>
              </div>
              <p className="text-[10px] text-slate-500 mb-2.5">
                {t.resetConfirmSubtitle}
              </p>
              <div className="flex items-center gap-2 w-full">
                <button
                  onClick={() => {
                    soundManager.playHit();
                    onResetProgress();
                    setShowConfirmReset(false);
                  }}
                  className="flex-1 py-1.5 rounded-xl bg-[#FF4D65] text-white font-display font-bold text-xs active:scale-95 cursor-pointer"
                >
                  {t.yesReset}
                </button>
                <button
                  onClick={() => setShowConfirmReset(false)}
                  className="flex-1 py-1.5 rounded-xl bg-white border border-slate-200 text-slate-700 font-display font-bold text-xs active:scale-95 cursor-pointer"
                >
                  {t.cancel}
                </button>
              </div>
            </div>
          ) : (
            <button
              onClick={() => setShowConfirmReset(true)}
              className="w-full py-2 px-3 rounded-2xl bg-white border border-rose-200 text-[#FF4D65] font-display font-bold text-xs flex items-center justify-center gap-1.5 active:scale-95 transition-transform cursor-pointer"
            >
              <Trash2 className="w-3.5 h-3.5" />
              <span>{t.resetProgress}</span>
            </button>
          )}
        </div>
      </div>
    </div>
  );
};
