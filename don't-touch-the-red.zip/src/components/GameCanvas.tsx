import React, { useEffect, useRef, useState, useCallback } from 'react';
import { GameEngine } from '../game/GameEngine';
import { ActivePowerUp, ComboState, RunSummary, SkinId } from '../types/game';
import { Pause } from 'lucide-react';
import { soundManager } from '../audio/soundManager';

import { PASTEL_THEMES, PastelTheme } from '../data/themes';
import { getTranslation, Language } from '../utils/i18n';

interface GameCanvasProps {
  selectedSkinId: SkinId;
  reducedMotion: boolean;
  lang?: Language;
  onGameOver: (summary: RunSummary) => void;
  onPause: () => void;
  isPaused: boolean;
}

export const GameCanvas: React.FC<GameCanvasProps> = ({
  selectedSkinId,
  reducedMotion,
  lang = 'en',
  onGameOver,
  onPause,
  isPaused,
}) => {
  const t = getTranslation(lang);
  const containerRef = useRef<HTMLDivElement | null>(null);
  const canvasRef = useRef<HTMLCanvasElement | null>(null);
  const engineRef = useRef<GameEngine | null>(null);

  const [currentScore, setCurrentScore] = useState(0);
  const [currentCoins, setCurrentCoins] = useState(0);
  const [activePowerUps, setActivePowerUps] = useState<ActivePowerUp[]>([]);
  const [milestoneMessage, setMilestoneMessage] = useState<string | null>(null);
  const [currentTheme, setCurrentTheme] = useState<PastelTheme>(PASTEL_THEMES[0]);
  const [comboState, setComboState] = useState<ComboState>({
    count: 0,
    multiplier: 1.0,
    timer: 0,
    maxTimer: 2.4,
  });

  // Touch tracking for immediate swipe & tap
  const touchStartPos = useRef<{ x: number; y: number } | null>(null);
  const touchStartTime = useRef<number>(0);
  const hasSwiped = useRef<boolean>(false);

  // Setup GameEngine with ResizeObserver for ultra-flexible viewport fitting
  useEffect(() => {
    const canvas = canvasRef.current;
    if (!canvas) return;

    const engine = new GameEngine(canvas);
    engine.setSkin(selectedSkinId);
    engine.setReducedMotion(reducedMotion);

    engine.onScoreUpdate = (score) => setCurrentScore(score);
    engine.onCoinsUpdate = (coins) => setCurrentCoins(coins);
    engine.onPowerUpChange = (powerUps) => setActivePowerUps([...powerUps]);
    engine.onThemeChange = (theme) => setCurrentTheme(theme);
    engine.onComboUpdate = (combo) => setComboState(combo);
    engine.onMilestone = (text) => {
      setMilestoneMessage(text);
      setTimeout(() => setMilestoneMessage(null), 2200);
    };
    engine.onGameOver = (summary) => onGameOver(summary);

    engineRef.current = engine;
    engine.start();

    // Fast resize handling with ResizeObserver + window listener for full cross-browser reliability
    const handleResize = () => {
      engine.resize();
    };

    window.addEventListener('resize', handleResize, { passive: true });
    window.addEventListener('orientationchange', handleResize, { passive: true });

    let ro: ResizeObserver | null = null;
    if (typeof ResizeObserver !== 'undefined' && containerRef.current) {
      ro = new ResizeObserver(() => {
        engine.resize();
      });
      ro.observe(containerRef.current);
    }

    // Auto pause on tab blur or visibility hidden
    const handleVisibilityChange = () => {
      if (document.hidden) {
        engine.pause();
        onPause();
      }
    };
    document.addEventListener('visibilitychange', handleVisibilityChange);

    return () => {
      engine.stop();
      window.removeEventListener('resize', handleResize);
      window.removeEventListener('orientationchange', handleResize);
      if (ro) ro.disconnect();
      document.removeEventListener('visibilitychange', handleVisibilityChange);
    };
  }, [selectedSkinId, reducedMotion, onGameOver, onPause]);

  // Handle pause / resume external state
  useEffect(() => {
    if (!engineRef.current) return;
    if (isPaused) {
      engineRef.current.pause();
    } else {
      engineRef.current.resume();
    }
  }, [isPaused]);

  // Keyboard controls
  const handleKeyDown = useCallback(
    (e: KeyboardEvent) => {
      if (!engineRef.current || isPaused) return;

      if (e.key === 'ArrowLeft' || e.key === 'a' || e.key === 'A') {
        engineRef.current.moveLeft();
      } else if (e.key === 'ArrowRight' || e.key === 'd' || e.key === 'D') {
        engineRef.current.moveRight();
      } else if (e.key === 'Escape' || e.key === 'p' || e.key === 'P') {
        soundManager.playClick();
        onPause();
      }
    },
    [isPaused, onPause]
  );

  useEffect(() => {
    window.addEventListener('keydown', handleKeyDown);
    return () => window.removeEventListener('keydown', handleKeyDown);
  }, [handleKeyDown]);

  // High-responsiveness Touch Handlers (Immediate directional swipe recognition)
  const handleTouchStart = (e: React.TouchEvent<HTMLDivElement>) => {
    if (e.touches.length > 0) {
      const touch = e.touches[0];
      touchStartPos.current = { x: touch.clientX, y: touch.clientY };
      touchStartTime.current = performance.now();
      hasSwiped.current = false;
    }
  };

  const handleTouchMove = (e: React.TouchEvent<HTMLDivElement>) => {
    if (!touchStartPos.current || hasSwiped.current || !engineRef.current || isPaused) return;
    const touch = e.touches[0];
    const dx = touch.clientX - touchStartPos.current.x;
    const dy = touch.clientY - touchStartPos.current.y;

    // Instant swipe threshold (18px) for snappier, lag-free mobile gameplay
    if (Math.abs(dx) > 18 && Math.abs(dx) > Math.abs(dy) * 1.1) {
      hasSwiped.current = true;
      if (dx < 0) {
        engineRef.current.moveLeft();
      } else {
        engineRef.current.moveRight();
      }
    }
  };

  const handleTouchEnd = (e: React.TouchEvent<HTMLDivElement>) => {
    if (!touchStartPos.current || !engineRef.current || isPaused) return;

    // If swipe was not already triggered during drag, check tap
    if (!hasSwiped.current) {
      const dt = performance.now() - touchStartTime.current;
      const touch = e.changedTouches[0];
      const dx = touch.clientX - touchStartPos.current.x;
      const dy = touch.clientY - touchStartPos.current.y;

      if (dt < 320 && Math.hypot(dx, dy) < 22) {
        const rect = canvasRef.current?.getBoundingClientRect();
        if (rect) {
          const clickX = touch.clientX - rect.left;
          const width = rect.width;
          if (clickX < width * 0.33) {
            engineRef.current.setLane(0);
          } else if (clickX < width * 0.67) {
            engineRef.current.setLane(1);
          } else {
            engineRef.current.setLane(2);
          }
        }
      }
    }

    touchStartPos.current = null;
    hasSwiped.current = false;
  };

  // Mouse fallback for desktop browsers
  const handleMouseDown = (e: React.MouseEvent<HTMLDivElement>) => {
    if (!engineRef.current || isPaused) return;
    const rect = canvasRef.current?.getBoundingClientRect();
    if (rect) {
      const clickX = e.clientX - rect.left;
      const width = rect.width;
      if (clickX < width * 0.33) {
        engineRef.current.setLane(0);
      } else if (clickX < width * 0.67) {
        engineRef.current.setLane(1);
      } else {
        engineRef.current.setLane(2);
      }
    }
  };

  return (
    <div
      ref={containerRef}
      className="relative w-full h-full max-w-md mx-auto flex flex-col items-center select-none overflow-hidden touch-none"
      onTouchStart={handleTouchStart}
      onTouchMove={handleTouchMove}
      onTouchEnd={handleTouchEnd}
      onMouseDown={handleMouseDown}
    >
      {/* Canvas Viewport */}
      <canvas
        ref={canvasRef}
        className="w-full h-full block cursor-pointer select-none"
      />

      {/* Top HUD Overlay (Responsive on all screen sizes) */}
      <div className="absolute top-0 left-0 right-0 p-3 sm:p-4 flex items-center justify-between pointer-events-none z-10 pt-[max(env(safe-area-inset-top),12px)]">
        {/* Score & Coins */}
        <div className="flex items-center gap-1.5 sm:gap-2.5 min-w-0">
          <div className="bg-white/95 backdrop-blur-sm px-3 sm:px-4 py-1.5 rounded-2xl shadow-sm border border-slate-200 flex flex-col items-start min-w-[62px]">
            <span className="text-[9px] sm:text-[10px] font-semibold text-slate-400 uppercase tracking-wider">{t.score}</span>
            <span className="font-display font-extrabold text-xl sm:text-2xl text-[#343047] tabular-nums leading-none">
              {currentScore}
            </span>
          </div>

          <div className="bg-white/95 backdrop-blur-sm px-2.5 sm:px-3 py-1.5 sm:py-2 rounded-2xl shadow-sm border border-[#FFD65A]/80 flex items-center gap-1">
            <span className="text-sm sm:text-base">🪙</span>
            <span className="font-display font-bold text-xs sm:text-sm text-[#343047] tabular-nums leading-none">
              +{currentCoins}
            </span>
          </div>

          {/* Active Pastel World Badge (Collapses gracefully on small widths) */}
          <div
            className="hidden min-[360px]:flex items-center gap-1 bg-white/95 backdrop-blur-sm px-2 sm:px-2.5 py-1.5 rounded-2xl shadow-sm border border-slate-200/90"
            title={`Zone: ${currentTheme.name}`}
          >
            <span className="text-xs">{currentTheme.badgeEmoji}</span>
            <span className="font-display font-semibold text-[10px] sm:text-[11px] text-[#343047] whitespace-nowrap hidden min-[390px]:inline">
              {currentTheme.name}
            </span>
          </div>
        </div>

        {/* Pause Button */}
        <button
          onClick={(e) => {
            e.stopPropagation();
            soundManager.playClick();
            onPause();
          }}
          className="pointer-events-auto min-w-[40px] min-h-[40px] p-2 sm:p-2.5 rounded-2xl bg-white/95 backdrop-blur-sm border border-slate-200 text-[#343047] shadow-sm active:scale-90 transition-transform flex items-center justify-center cursor-pointer ml-1"
          title="Pause Game"
        >
          <Pause className="w-4 h-4 sm:w-5 sm:h-5 fill-current" />
        </button>
      </div>

      {/* Active Power-Ups Indicators */}
      {activePowerUps.length > 0 && (
        <div className="absolute top-20 left-4 flex flex-col gap-1.5 pointer-events-none z-10">
          {activePowerUps.map((pu) => {
            const pct = Math.max(0, Math.min(100, (pu.duration / pu.maxDuration) * 100));
            const icon =
              pu.type === 'SHIELD' ? '🛡️' :
              pu.type === 'MAGNET' ? '🧲' :
              pu.type === 'SLOWMO' ? '⏳' : '2X';
            const label =
              pu.type === 'SHIELD' ? 'Shield' :
              pu.type === 'MAGNET' ? 'Magnet' :
              pu.type === 'SLOWMO' ? 'Slow-Mo' : 'Double';

            return (
              <div
                key={pu.type}
                className="bg-white/90 backdrop-blur-sm border border-slate-200/90 rounded-xl px-2.5 py-1 flex items-center gap-2 shadow-sm"
              >
                <span className="text-sm">{icon}</span>
                <div className="flex flex-col">
                  <div className="flex items-center justify-between text-[10px] font-bold text-slate-700">
                    <span>{label}</span>
                    <span className="tabular-nums ml-2">{Math.ceil(pu.duration)}s</span>
                  </div>
                  {/* Progress bar */}
                  <div className="w-16 h-1 bg-slate-200 rounded-full overflow-hidden mt-0.5">
                    <div
                      className="h-full bg-[#72D7FF] transition-all duration-100"
                      style={{ width: `${pct}%` }}
                    />
                  </div>
                </div>
              </div>
            );
          })}
        </div>
      )}

      {/* Dynamic Combo Meter & Visual Multiplier HUD */}
      {comboState.count >= 2 && (
        <div className="absolute top-20 right-4 flex flex-col items-end pointer-events-none z-10 animate-in fade-in slide-in-from-right duration-200">
          <div
            className={`px-3 py-1.5 rounded-2xl shadow-md border backdrop-blur-md flex flex-col items-end gap-1 ${
              comboState.multiplier >= 3.0
                ? 'bg-gradient-to-r from-rose-500/95 to-amber-500/95 border-amber-300 text-white shadow-rose-400/40'
                : comboState.multiplier >= 2.0
                ? 'bg-[#FFD65A]/95 border-amber-200 text-[#343047] shadow-amber-300/40'
                : 'bg-white/95 border-purple-200/90 text-[#343047]'
            }`}
          >
            <div className="flex items-center gap-1.5">
              <span className={`text-sm ${comboState.multiplier >= 2.0 ? 'animate-bounce' : ''}`}>
                {comboState.multiplier >= 3.0 ? '🔥' : comboState.multiplier >= 2.0 ? '⚡' : '✨'}
              </span>
              <span className="font-display font-extrabold text-xs tracking-wider uppercase">
                {comboState.count} {t.combo}
              </span>
              <span
                className={`font-display font-black text-xs px-2 py-0.5 rounded-lg shadow-inner ${
                  comboState.multiplier >= 3.0
                    ? 'bg-white text-rose-600'
                    : comboState.multiplier >= 2.0
                    ? 'bg-[#343047] text-[#FFD65A]'
                    : 'bg-[#B8A7FF]/30 text-purple-800'
                }`}
              >
                {comboState.multiplier.toFixed(1)}x
              </span>
            </div>

            {/* Visual Gauge / Decay Bar */}
            <div className="w-24 h-1.5 bg-black/15 rounded-full overflow-hidden">
              <div
                className={`h-full transition-all duration-200 ease-linear rounded-full ${
                  comboState.multiplier >= 3.0
                    ? 'bg-yellow-200'
                    : comboState.multiplier >= 2.0
                    ? 'bg-[#343047]'
                    : 'bg-[#B8A7FF]'
                }`}
                style={{
                  width: `${Math.max(0, Math.min(100, (comboState.timer / comboState.maxTimer) * 100))}%`,
                }}
              />
            </div>
          </div>
        </div>
      )}

      {/* Milestone Toast Overlay */}
      {milestoneMessage && (
        <div className="absolute top-24 left-1/2 -translate-x-1/2 pointer-events-none z-20 animate-bounce">
          <div className="bg-[#FFD65A] text-[#343047] px-4 py-2 rounded-2xl shadow-lg border-2 border-white font-display font-extrabold text-sm whitespace-nowrap">
            🎉 {milestoneMessage}
          </div>
        </div>
      )}

      {/* Subtle Onscreen Touch Navigation Guide (bottom) */}
      <div className="absolute bottom-2 left-0 right-0 px-6 py-2 flex justify-between text-[11px] font-semibold text-slate-400 pointer-events-none opacity-40">
        <span>{t.swipeLeft}</span>
        <span>{t.tapLanes}</span>
        <span>{t.swipeRight}</span>
      </div>
    </div>
  );
};
