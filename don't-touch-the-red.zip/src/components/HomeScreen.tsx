import React, { useState } from 'react';
import { SKINS } from '../data/skins';
import { SkinId } from '../types/game';
import { soundManager } from '../audio/soundManager';
import { getTranslation, Language } from '../utils/i18n';
import { Play, ShoppingBag, Trophy, Settings as SettingsIcon, Gift, Volume2, VolumeX, Maximize2, Minimize2, Tv } from 'lucide-react';

interface HomeScreenProps {
  highScore: number;
  totalCoins: number;
  selectedSkinId: SkinId;
  dailyRewardAvailable: boolean;
  soundEnabled: boolean;
  lang: Language;
  isFullscreen: boolean;
  onPlay: () => void;
  onOpenShop: () => void;
  onOpenAchievements: () => void;
  onOpenDaily: () => void;
  onOpenSettings: () => void;
  onToggleSound: () => void;
  onToggleFullscreen: () => void;
  onWatchRewardedAd: () => void;
}

export const HomeScreen: React.FC<HomeScreenProps> = ({
  highScore,
  totalCoins,
  selectedSkinId,
  dailyRewardAvailable,
  soundEnabled,
  lang,
  isFullscreen,
  onPlay,
  onOpenShop,
  onOpenAchievements,
  onOpenDaily,
  onOpenSettings,
  onToggleSound,
  onToggleFullscreen,
  onWatchRewardedAd,
}) => {
  const [characterTaps, setCharacterTaps] = useState(0);
  const skin = SKINS[selectedSkinId] || SKINS.original_blue;
  const t = getTranslation(lang);

  const handleCharacterTap = () => {
    soundManager.playStar();
    setCharacterTaps((prev) => prev + 1);
  };

  return (
    <div className="flex flex-col items-center justify-between w-full h-full max-w-md mx-auto p-4 sm:p-5 text-center select-none overflow-y-auto no-scrollbar">
      {/* Top Utility Bar */}
      <div className="w-full flex items-center justify-between pt-1 pb-2">
        {/* Coins Badge */}
        <div 
          onClick={() => {
            soundManager.playClick();
            onOpenShop();
          }}
          className="flex items-center gap-1.5 bg-white/90 border-2 border-[#FFD65A] px-3 py-1.5 rounded-full shadow-sm cursor-pointer hover:scale-105 active:scale-95 transition-transform"
        >
          <span className="text-lg">🪙</span>
          <span className="font-display font-bold text-sm text-[#343047] tabular-nums">{totalCoins}</span>
        </div>

        {/* Action icons */}
        <div className="flex items-center gap-1.5">
          {/* Daily Reward Button with pulse if available */}
          <button
            onClick={() => {
              soundManager.playClick();
              onOpenDaily();
            }}
            className={`relative p-2 rounded-2xl bg-white border-2 transition-all ${
              dailyRewardAvailable
                ? 'border-[#FF4D65] text-[#FF4D65] shadow-md shadow-[#FF4D65]/20 animate-bounce'
                : 'border-slate-200 text-slate-600'
            } active:scale-90`}
            title={t.dailyGift}
          >
            <Gift className="w-4 h-4" />
            {dailyRewardAvailable && (
              <span className="absolute -top-1 -right-1 w-2.5 h-2.5 bg-[#FF4D65] rounded-full ring-2 ring-white" />
            )}
          </button>

          {/* Fullscreen Toggle */}
          <button
            onClick={() => {
              soundManager.playClick();
              onToggleFullscreen();
            }}
            className="p-2 rounded-2xl bg-white border-2 border-slate-200 text-slate-600 active:scale-90 transition-transform"
            title={t.fullscreenToggle}
          >
            {isFullscreen ? <Minimize2 className="w-4 h-4 text-[#72D7FF]" /> : <Maximize2 className="w-4 h-4" />}
          </button>

          {/* Quick Sound Toggle */}
          <button
            onClick={() => {
              soundManager.playClick();
              onToggleSound();
            }}
            className="p-2 rounded-2xl bg-white border-2 border-slate-200 text-slate-600 active:scale-90 transition-transform"
            title={t.soundEffects}
          >
            {soundEnabled ? <Volume2 className="w-4 h-4 text-slate-700" /> : <VolumeX className="w-4 h-4 text-slate-400" />}
          </button>

          {/* Settings Button */}
          <button
            onClick={() => {
              soundManager.playClick();
              onOpenSettings();
            }}
            className="p-2 rounded-2xl bg-white border-2 border-slate-200 text-slate-600 active:scale-90 transition-transform"
            title={t.settings}
          >
            <SettingsIcon className="w-4 h-4" />
          </button>
        </div>
      </div>

      {/* Main Logo & Title */}
      <div className="flex flex-col items-center my-auto py-1">
        <div className="inline-flex items-center gap-1.5 px-3 py-1 rounded-full bg-[#FF4D65]/10 border border-[#FF4D65]/30 text-[#FF4D65] text-xs font-semibold uppercase tracking-wider mb-2">
          <span>⚠️</span> {t.avoidRedBadge}
        </div>

        <h1 className="font-display font-extrabold text-4xl sm:text-5xl leading-tight text-[#343047] tracking-tight">
          {t.gameTitleTop}
          <br />
          <span className="text-[#FF4D65] drop-shadow-[0_4px_12px_rgba(255,77,101,0.35)]">
            {t.gameTitleBottom}
          </span>
        </h1>

        <p className="text-xs sm:text-sm font-medium text-slate-500 mt-2 max-w-xs px-2">
          {t.homeSubtitle}
        </p>

        {/* Interactive Character Mascot Preview */}
        <div 
          onClick={handleCharacterTap}
          className="relative my-5 cursor-pointer group"
          title={t.tapToPlay}
        >
          {/* Mascot Glow */}
          <div 
            className="w-28 h-28 sm:w-32 sm:h-32 rounded-full flex items-center justify-center shadow-xl animate-cute-bounce transition-transform duration-200 group-hover:scale-105"
            style={{
              background: skin.isRainbow
                ? 'linear-gradient(135deg, #FF6B6B, #4ECDC4, #FFE66D)'
                : skin.isGalaxy
                ? 'radial-gradient(circle at 35% 35%, #7597DE, #4B1055, #1A0835)'
                : `radial-gradient(circle at 35% 35%, ${skin.accentColor}, ${skin.primaryColor}, ${skin.secondaryColor})`,
              boxShadow: `0 14px 28px ${skin.secondaryColor}40`,
            }}
          >
            {/* Expressive Face */}
            <div className="relative flex flex-col items-center select-none pointer-events-none">
              {/* Crown accessory if equipped */}
              {skin.hasCrown && (
                <span className="absolute -top-11 text-2xl animate-bounce">👑</span>
              )}
              {/* Sprout if equipped */}
              {skin.hasLeaves && (
                <span className="absolute -top-9 text-2xl">🌱</span>
              )}

              {/* Eyes */}
              <div className="flex items-center gap-4 mb-1">
                {characterTaps % 2 === 1 ? (
                  <>
                    <span className="font-display font-bold text-xl text-[#343047]">^</span>
                    <span className="font-display font-bold text-xl text-[#343047]">^</span>
                  </>
                ) : (
                  <>
                    <div className="w-3.5 h-3.5 rounded-full bg-[#343047] relative">
                      <div className="w-1.5 h-1.5 rounded-full bg-white absolute top-0.5 left-0.5" />
                    </div>
                    <div className="w-3.5 h-3.5 rounded-full bg-[#343047] relative">
                      <div className="w-1.5 h-1.5 rounded-full bg-white absolute top-0.5 left-0.5" />
                    </div>
                  </>
                )}
              </div>

              {/* Cheeks */}
              <div className="w-full flex justify-between px-1 mb-1">
                <div className="w-2.5 h-1.5 rounded-full bg-[#FF4D65]/40" />
                <div className="w-2.5 h-1.5 rounded-full bg-[#FF4D65]/40" />
              </div>

              {/* Smiling mouth */}
              <div className="w-3 h-1.5 border-b-2 border-[#343047] rounded-b-full" />
            </div>
          </div>

          {/* Skin Name Tag */}
          <div className="mt-2 text-xs font-semibold text-slate-500 tracking-wide uppercase">
            {skin.name}
          </div>
        </div>

        {/* High Score Banner */}
        <div className="bg-white/80 border border-slate-200/80 rounded-2xl px-5 py-2 shadow-sm flex items-center gap-3">
          <span className="text-xl">🏆</span>
          <div className="text-left">
            <div className="text-[10px] font-semibold tracking-wider text-slate-400 uppercase">{t.personalBest}</div>
            <div className="font-display font-extrabold text-lg text-[#343047] tabular-nums leading-none">
              {highScore} <span className="text-xs font-normal text-slate-500">{t.pts}</span>
            </div>
          </div>
        </div>
      </div>

      {/* Bottom Action Area */}
      <div className="w-full flex flex-col gap-2.5 pb-2 pt-2">
        {/* Big PLAY Button */}
        <button
          onClick={() => {
            soundManager.playClick();
            onPlay();
          }}
          className="w-full py-3.5 sm:py-4 rounded-2xl font-display font-bold text-xl text-white bg-gradient-to-r from-[#FF4D65] to-[#FF6B81] shadow-lg shadow-[#FF4D65]/35 hover:brightness-105 active:scale-95 transition-all flex items-center justify-center gap-3 cursor-pointer"
        >
          <Play className="w-6 h-6 fill-current" />
          <span>{t.playNow}</span>
        </button>

        {/* Secondary Hub Buttons */}
        <div className="grid grid-cols-2 gap-2">
          <button
            onClick={() => {
              soundManager.playClick();
              onOpenShop();
            }}
            className="py-2.5 px-3 rounded-2xl bg-white border-2 border-slate-200/90 font-display font-bold text-xs sm:text-sm text-[#343047] shadow-sm hover:border-slate-300 active:scale-95 transition-all flex items-center justify-center gap-2"
          >
            <ShoppingBag className="w-4 h-4 text-[#72D7FF]" />
            <span>{t.characterShop}</span>
          </button>

          <button
            onClick={() => {
              soundManager.playClick();
              onOpenAchievements();
            }}
            className="py-2.5 px-3 rounded-2xl bg-white border-2 border-slate-200/90 font-display font-bold text-xs sm:text-sm text-[#343047] shadow-sm hover:border-slate-300 active:scale-95 transition-all flex items-center justify-center gap-2"
          >
            <Trophy className="w-4 h-4 text-[#FFD65A]" />
            <span>{t.achievements}</span>
          </button>
        </div>

        {/* Rewarded Video Ad Bonus Button */}
        <button
          onClick={() => {
            soundManager.playClick();
            onWatchRewardedAd();
          }}
          className="w-full py-2 px-3 rounded-xl bg-amber-50 hover:bg-amber-100 border border-amber-200/80 text-amber-800 font-display font-bold text-xs flex items-center justify-center gap-2 active:scale-95 transition-all"
        >
          <Tv className="w-3.5 h-3.5 text-amber-600" />
          <span>{t.watchAdCoins}</span>
        </button>
      </div>
    </div>
  );
};
